import React from 'react'

const FarmMachinerySubcategory = () => {
  return (
    <div>FarmMachinerySubcategory</div>
  )
}

export default FarmMachinerySubcategory