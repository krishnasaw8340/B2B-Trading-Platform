import React from 'react'

const AgritechSolutionProduct = () => {
  return (
    <div>AgritechSolutionProduct</div>
  )
}

export default AgritechSolutionProduct