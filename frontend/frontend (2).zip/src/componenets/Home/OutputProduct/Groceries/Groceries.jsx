import React from 'react'

const Groceries = () => {
  return (
    <div>Groceries</div>
  )
}

export default Groceries