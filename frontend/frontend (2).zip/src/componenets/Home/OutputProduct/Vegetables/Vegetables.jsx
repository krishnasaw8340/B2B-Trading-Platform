import React from 'react'

const Vegetables = () => {
  return (
    <div>Vegetables</div>
  )
}

export default Vegetables