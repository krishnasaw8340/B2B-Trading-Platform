import React from 'react'

const SeedsAndPlantProduct = () => {
  return (
    <div>SeedsAndPlantProduct</div>
  )
}

export default SeedsAndPlantProduct