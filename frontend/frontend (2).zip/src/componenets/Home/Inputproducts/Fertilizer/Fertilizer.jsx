import React from 'react'

const Fertilizer = () => {
  return (
    <div>Fertilizer</div>
  )
}

export default Fertilizer