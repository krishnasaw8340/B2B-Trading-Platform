import React from 'react'

const CultivatiionType = () => {
  return (
    <div>CultivatiionType</div>
  )
}

export default CultivatiionType