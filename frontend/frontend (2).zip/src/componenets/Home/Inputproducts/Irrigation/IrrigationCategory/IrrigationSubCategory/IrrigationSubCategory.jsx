import React from 'react'

const IrrigationSubCategory = () => {
  return (
    <div>IrrigationSubCategory</div>
  )
}

export default IrrigationSubCategory