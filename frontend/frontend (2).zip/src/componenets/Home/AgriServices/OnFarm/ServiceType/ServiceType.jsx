import React from 'react'

const ServiceType = () => {
  return (
    <div>ServiceType</div>
  )
}

export default ServiceType