import React from 'react'
import Enquiry from './PostReqData/Enquiry'

const UserEnquiry = () => {
  return (
    <div>
      <Enquiry/>
    </div>
  )
}

export default UserEnquiry