import React from 'react'

const EnqCard = ({formData}) => {
  return (
    <div>
        {formData && formData}
    </div>
  )
}

export default EnqCard