import React from 'react'

const AgriIrrigation = () => {
  return (
    <div>AgriIrrigation</div>
  )
}

export default AgriIrrigation