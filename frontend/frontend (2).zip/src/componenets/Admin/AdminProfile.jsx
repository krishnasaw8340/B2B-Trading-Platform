import React from 'react'

const AdminProfile = () => {
  return (
    <div>AdminProfile</div>
  )
}

export default AdminProfile