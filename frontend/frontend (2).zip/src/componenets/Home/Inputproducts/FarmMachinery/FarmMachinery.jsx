import React from 'react'

const FarmMachinery = () => {
  return (
    <div>FarmMachinery</div>
  )
}

export default FarmMachinery