import React from 'react'

const Croptype = () => {
  return (
    <div>Croptype</div>
  )
}

export default Croptype