import React from 'react'

export const VerifyEmail = () => {
  return (
    <div>VerifyEmail</div>
  )
}
