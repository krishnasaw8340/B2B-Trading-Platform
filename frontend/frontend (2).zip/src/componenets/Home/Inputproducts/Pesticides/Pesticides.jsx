import React from 'react'

const Pesticides = () => {
  return (
    <div>Pesticides</div>
  )
}

export default Pesticides