import React from 'react'

const AlliedActivities = () => {
  return (
    <div>AlliedActivities</div>
  )
}

export default AlliedActivities