// export const MongoURl = "mongodb+srv://way2agribusiness:way2agribusiness@cluster0.bhzhnvq.mongodb.net/e-commerce?retryWrites=true&w=majority"
export const MongoURl = "mongodb+srv://way2agritech:tCjLTVdFpMPLOQV0@cluster0.ebcqrj1.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
export const PORT = 5000