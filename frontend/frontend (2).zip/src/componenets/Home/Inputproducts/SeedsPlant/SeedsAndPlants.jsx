import React from 'react'

const SeedsAndPlants = () => {
  return (
    <div>SeedsAndPlants</div>
  )
}

export default SeedsAndPlants