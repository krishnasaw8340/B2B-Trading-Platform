import React from 'react'

const Implements = () => {
  return (
    <div>Implements</div>
  )
}

export default Implements