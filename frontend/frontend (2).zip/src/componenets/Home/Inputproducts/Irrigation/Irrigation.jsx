import React from 'react'

const Irrigation = () => {
  return (
    <div>Irrigation</div>
  )
}

export default Irrigation