import React from 'react'

const FertilizerProduct = () => {
  return (
    <div>FertilizerProduct</div>
  )
}

export default FertilizerProduct