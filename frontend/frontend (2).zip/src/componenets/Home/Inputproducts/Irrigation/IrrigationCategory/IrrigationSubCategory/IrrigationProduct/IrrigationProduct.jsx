import React from 'react'

const IrrigationProduct = () => {
  return (
    <div>IrrigationProduct</div>
  )
}

export default IrrigationProduct