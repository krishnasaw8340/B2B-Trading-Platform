import React from 'react'

const UnauthorizedPage = () => {
  return (
    <div>This is 404, Not found page ! </div>
  )
}

export default UnauthorizedPage