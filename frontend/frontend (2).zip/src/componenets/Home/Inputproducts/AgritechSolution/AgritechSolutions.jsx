import React from 'react'

const AgritechSolutions = () => {
  return (
    <div>AgritechSolutions</div>
  )
}

export default AgritechSolutions