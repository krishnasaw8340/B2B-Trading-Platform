import React from 'react'

const FarmSize = () => {
  return (
    <div>FarmSize</div>
  )
}

export default FarmSize