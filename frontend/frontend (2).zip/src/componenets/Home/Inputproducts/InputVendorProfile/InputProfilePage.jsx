import React from 'react'

const InputProfilePage = () => {
  return (
    <div>InputProfilePage</div>
  )
}

export default InputProfilePage