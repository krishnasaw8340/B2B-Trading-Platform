import React from 'react'

const ProductApproval = () => {
  return (
    <div>ProductApproval</div>
  )
}

export default ProductApproval