import React from 'react'

const Fruits = () => {
  return (
    <div>Fruits</div>
  )
}

export default Fruits