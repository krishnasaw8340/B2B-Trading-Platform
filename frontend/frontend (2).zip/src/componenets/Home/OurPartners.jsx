import React from 'react'

const OurPartners = () => {
  return (
    <div>OurPartners</div>
  )
}

export default OurPartners