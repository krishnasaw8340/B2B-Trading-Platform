import React from 'react'

const PesticidesProduct = () => {
  return (
    <div>PesticidesProduct</div>
  )
}

export default PesticidesProduct