import React from 'react'

const GrocerySubCategory = () => {
  return (
    <div>GrocerySubCategory</div>
  )
}

export default GrocerySubCategory